# Wevlo — Website & Code → Android APK SaaS

Full-stack React + Vite + TypeScript + Supabase SaaS clone of wevlo.pages.dev

## Setup

1. `npm install`
2. `cp .env.example .env` and fill in your Supabase credentials
3. `npm run dev`

## Supabase

1. Create project at supabase.com
2. Run `supabase/schema.sql` in SQL Editor
3. Create Storage bucket named `icons` (public)
4. Enable Email + Google + GitHub auth providers
5. Add `http://localhost:5173/auth/callback` to Redirect URLs

## Deploy

### Vercel
- Push to GitHub
- Import to Vercel
- Add env vars: `VITE_SUPABASE_URL`, `VITE_SUPABASE_ANON_KEY`
- Add your Vercel URL + `/auth/callback` to Supabase redirects

### Cloudflare Pages
- Build: `npm run build`, Output: `dist`
- Same env vars

## Features
- Website → APK conversion (simulated)
- Monaco-powered code editor with live preview
- Supabase auth (Email + OAuth)
- Dark mode, responsive, accessible
- Protected dashboard routes
- Draft autosave to localStorage
