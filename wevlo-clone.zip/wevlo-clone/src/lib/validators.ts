import { z } from 'zod'

export const signInSchema = z.object({
  email: z.string().email('Enter a valid email'),
  password: z.string().min(8, 'Password must be at least 8 characters'),
})
export type SignInValues = z.infer<typeof signInSchema>

export const websiteFormSchema = z.object({
  url: z.string().url('Enter a valid URL').startsWith('https://', 'URL must use HTTPS'),
  name: z.string().min(3, 'Min 3 characters').max(30, 'Max 30 characters'),
  packageId: z.string().regex(/^[a-z][a-z0-9]*(\.[a-z][a-z0-9]*)+$/, 'Format: com.example.app'),
  splashColor: z.string().regex(/^#[0-9a-fA-F]{6}$/, 'Invalid color'),
  permissions: z.array(z.string()),
})
export type WebsiteFormValues = z.infer<typeof websiteFormSchema>