import { clsx, type ClassValue } from 'clsx'
import { twMerge } from 'tailwind-merge'

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export function generatePackageId(name: string): string {
  const slug = name.toLowerCase().replace(/[^a-z0-9]+/g, '').replace(/^[^a-z]+/, '')
  return `com.wevlo.${slug || 'app'}`
}