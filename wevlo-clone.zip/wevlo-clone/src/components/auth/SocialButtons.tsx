import { toast } from 'sonner'
import { supabase } from '@/lib/supabase'
import { Button } from '@/components/ui/button'

function GoogleIcon() {
  return (
    <svg className="h-4 w-4" viewBox="0 0 24 24" aria-hidden>
      <path fill="#EA4335" d="M12 5.04c1.71 0 3.24.59 4.45 1.75l3.32-3.32C17.8 1.56 15.13.5 12 .5 7.3.5 3.24 3.2 1.28 7.11l3.87 3C6.11 7.24 8.83 5.04 12 5.04z" />
      <path fill="#4285F4" d="M23.49 12.27c0-.79-.07-1.54-.2-2.27H12v4.51h6.44c-.28 1.48-1.12 2.74-2.38 3.58l3.66 2.84c2.14-1.97 3.77-4.87 3.77-8.66z" />
      <path fill="#FBBC05" d="M5.15 14.11a7.2 7.2 0 0 1 0-4.22L1.28 6.89A11.99 11.99 0 0 0 0 12c0 1.94.46 3.77 1.28 5.11l3.87-3z" />
      <path fill="#34A853" d="M12 23.5c3.24 0 5.96-1.07 7.94-2.9l-3.66-2.84c-1.02.68-2.32 1.09-3.78 1.09-3.17 0-5.89-2.2-6.85-5.16l-3.87 3C3.24 20.8 7.3 23.5 12 23.5z" />
    </svg>
  )
}
function GitHubIcon() {
  return (
    <svg className="h-4 w-4" viewBox="0 0 24 24" fill="currentColor" aria-hidden>
      <path d="M12 .5C5.65.5.5 5.65.5 12c0 5.08 3.29 9.38 7.86 10.9.58.1.79-.25.79-.55v-1.93c-3.2.7-3.88-1.36-3.88-1.36-.52-1.32-1.28-1.67-1.28-1.67-1.04-.71.08-.7.08-.7 1.15.08 1.76 1.18 1.76 1.18 1.03 1.77 2.7 1.26 3.36.97.1-.75.4-1.26.72-1.55-2.55-.29-5.24-1.28-5.24-5.7 0-1.26.45-2.29 1.18-3.1-.12-.29-.51-1.46.11-3.05 0 0 .97-.31 3.18 1.18a11 11 0 0 1 5.79 0c2.2-1.49 3.18-1.18 3.18-1.18.62 1.59.23 2.76.11 3.05.74.81 1.18 1.84 1.18 3.1 0 4.43-2.7 5.41-5.26 5.69.41.35.77 1.04.77 2.1v3.11c0 .31.21.66.79.55A10.99 10.99 0 0 0 23.5 12C23.5 5.65 18.35.5 12 .5z" />
    </svg>
  )
}

export function SocialButtons() {
  const signIn = async (provider: 'google' | 'github') => {
    const { error } = await supabase.auth.signInWithOAuth({
      provider,
      options: { redirectTo: `${window.location.origin}/auth/callback` },
    })
    if (error) toast.error(error.message)
  }
  return (
    <div className="grid gap-2">
      <Button variant="outline" onClick={() => signIn('google')} className="w-full"><GoogleIcon /><span className="ml-2">Continue with Google</span></Button>
      <Button variant="outline" onClick={() => signIn('github')} className="w-full"><GitHubIcon /><span className="ml-2">Continue with GitHub</span></Button>
    </div>
  )
}