import { useState } from 'react'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { Link, useNavigate } from 'react-router-dom'
import { motion } from 'framer-motion'
import { Eye, EyeOff, Lock } from 'lucide-react'
import { toast } from 'sonner'
import { signInSchema, type SignInValues } from '@/lib/validators'
import { supabase } from '@/lib/supabase'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { SocialButtons } from './SocialButtons'
import { cn } from '@/lib/utils'

type Mode = 'signin' | 'signup'

export function AuthForm() {
  const [mode, setMode] = useState<Mode>('signin')
  const [showPw, setShowPw] = useState(false)
  const [pending, setPending] = useState(false)
  const navigate = useNavigate()
  const { register, handleSubmit, formState: { errors } } = useForm<SignInValues>({ resolver: zodResolver(signInSchema) })

  const onSubmit = async (values: SignInValues) => {
    setPending(true)
    try {
      if (mode === 'signin') {
        const { error } = await supabase.auth.signInWithPassword(values)
        if (error) throw error
        toast.success('Signed in')
        navigate('/dashboard')
      } else {
        const { error } = await supabase.auth.signUp(values)
        if (error) throw error
        toast.success('Account created. Check your email to verify.')
        setMode('signin')
      }
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Authentication failed')
    } finally { setPending(false) }
  }

  return (
    <div className="w-full max-w-md">
      <div className="mb-6 text-center">
        <h2 className="text-2xl font-bold tracking-tight">Welcome Back!</h2>
        <p className="mt-1 text-sm text-muted-foreground">Sign in to continue building apps</p>
      </div>
      <div className="mb-6 flex rounded-lg border border-border p-1">
        {(['signin', 'signup'] as const).map((m) => (
          <button key={m} type="button" onClick={() => setMode(m)} className="relative flex-1 rounded-md py-2 text-sm font-medium">
            {mode === m && <motion.div layoutId="auth-tab" className="absolute inset-0 rounded-md bg-primary/10" transition={{ type: 'spring', stiffness: 400, damping: 30 }} />}
            <span className={cn('relative', mode === m ? 'text-primary' : 'text-muted-foreground')}>{m === 'signin' ? 'Sign in' : 'Sign up'}</span>
          </button>
        ))}
      </div>
      <SocialButtons />
      <div className="my-6 flex items-center gap-3 text-xs text-muted-foreground">
        <div className="h-px flex-1 bg-border" /><span>or continue with email</span><div className="h-px flex-1 bg-border" />
      </div>
      <form onSubmit={handleSubmit(onSubmit)} className="space-y-4" noValidate>
        <div className="space-y-1.5">
          <Label htmlFor="email">Email</Label>
          <Input id="email" type="email" autoComplete="email" placeholder="you@example.com" aria-invalid={!!errors.email} aria-describedby={errors.email ? 'email-error' : undefined} {...register('email')} className={cn(errors.email && 'border-destructive focus-visible:ring-destructive')} />
          {errors.email && <p id="email-error" role="alert" className="text-xs text-destructive">{errors.email.message}</p>}
        </div>
        <div className="space-y-1.5">
          <Label htmlFor="password">Password</Label>
          <div className="relative">
            <Input id="password" type={showPw ? 'text' : 'password'} autoComplete={mode === 'signin' ? 'current-password' : 'new-password'} placeholder="••••••••" aria-invalid={!!errors.password} aria-describedby={errors.password ? 'password-error' : undefined} {...register('password')} className={cn('pr-10', errors.password && 'border-destructive focus-visible:ring-destructive')} />
            <button type="button" onClick={() => setShowPw((v) => !v)} className="absolute inset-y-0 right-0 grid place-items-center px-3 text-muted-foreground hover:text-foreground" aria-label={showPw ? 'Hide password' : 'Show password'}>
              {showPw ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
            </button>
          </div>
          {errors.password && <p id="password-error" role="alert" className="text-xs text-destructive">{errors.password.message}</p>}
        </div>
        <Button type="submit" className="w-full" disabled={pending}>
          {pending && <span className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-current border-t-transparent" />}
          {mode === 'signin' ? 'Sign in' : 'Create account'}
        </Button>
      </form>
      <p className="mt-6 text-center text-sm text-muted-foreground">
        Don't have an account?{' '}
        <button onClick={() => setMode('signup')} className="font-medium text-primary hover:underline">Sign up</button>
      </p>
      <p className="mt-2 text-center text-xs text-muted-foreground">
        By continuing you agree to the <Link to="/terms" className="underline hover:text-foreground">Terms</Link>
      </p>
      <div className="mt-6 flex items-center justify-center gap-2 rounded-lg border border-border bg-muted/50 px-3 py-2 text-xs text-muted-foreground">
        <Lock className="h-3.5 w-3.5" />Your projects stay on your device
      </div>
    </div>
  )
}