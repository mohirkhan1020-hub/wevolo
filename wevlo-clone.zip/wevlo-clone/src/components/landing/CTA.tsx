import { Link } from 'react-router-dom'
import { ArrowRight } from 'lucide-react'
import { Button } from '@/components/ui/button'

export function CTA() {
  return (
    <section className="py-20 md:py-28">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="relative overflow-hidden rounded-3xl bg-primary px-8 py-16 text-center text-primary-foreground">
          <div className="absolute inset-0 opacity-20 dot-grid" />
          <div className="relative">
            <h2 className="text-3xl md:text-4xl font-bold tracking-tight">Ship your app today</h2>
            <p className="mt-3 text-primary-foreground/80">It takes less than two minutes.</p>
            <Button asChild size="lg" variant="accent" className="mt-6"><Link to="/auth">Get Started Free <ArrowRight className="ml-2 h-4 w-4" /></Link></Button>
          </div>
        </div>
      </div>
    </section>
  )
}