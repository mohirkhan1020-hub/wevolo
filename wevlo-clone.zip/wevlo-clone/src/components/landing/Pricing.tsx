import { Link } from 'react-router-dom'
import { Check } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { cn } from '@/lib/utils'

const tiers = [
  { name: 'Free', price: '$0', period: '/mo', desc: 'Perfect to try it out.', features: ['1 app', 'Website → APK', 'Community support', 'Watermark'], cta: 'Start Free', featured: false },
  { name: 'Pro', price: '$9', period: '/mo', desc: 'For indie makers.', features: ['Unlimited apps', 'Code editor', 'Custom icons & splash', 'Priority builds', 'No watermark'], cta: 'Go Pro', featured: true },
  { name: 'Team', price: '$29', period: '/mo', desc: 'For growing teams.', features: ['Everything in Pro', '5 seats', 'Team workspaces', 'SSO', 'Priority support'], cta: 'Contact Sales', featured: false },
]

export function Pricing() {
  return (
    <section id="pricing" className="py-20 md:py-28">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-2xl text-center">
          <h2 className="text-3xl md:text-4xl font-bold tracking-tight">Simple pricing</h2>
          <p className="mt-4 text-muted-foreground">Start free. Upgrade when you're ready.</p>
        </div>
        <div className="mt-12 grid gap-6 md:grid-cols-3">
          {tiers.map((t) => (
            <div key={t.name} className={cn('relative rounded-2xl border bg-card p-8', t.featured ? 'border-primary shadow-xl shadow-primary/10 md:scale-105' : 'border-border')}>
              {t.featured && <Badge className="absolute -top-3 left-1/2 -translate-x-1/2">Most Popular</Badge>}
              <h3 className="font-semibold">{t.name}</h3>
              <div className="mt-2 flex items-baseline gap-1">
                <span className="text-4xl font-bold">{t.price}</span>
                <span className="text-muted-foreground">{t.period}</span>
              </div>
              <p className="mt-1 text-sm text-muted-foreground">{t.desc}</p>
              <ul className="mt-6 space-y-3">
                {t.features.map((f) => (
                  <li key={f} className="flex items-start gap-2 text-sm">
                    <Check className="mt-0.5 h-4 w-4 shrink-0 text-accent" />{f}
                  </li>
                ))}
              </ul>
              <Button asChild className="mt-8 w-full" variant={t.featured ? 'default' : 'outline'}>
                <Link to="/auth">{t.cta}</Link>
              </Button>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}