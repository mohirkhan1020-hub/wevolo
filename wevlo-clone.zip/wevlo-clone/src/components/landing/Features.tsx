import { motion } from 'framer-motion'
import { Globe, Code2, Zap, ShieldCheck, Image, Download } from 'lucide-react'

const features = [
  { icon: Globe, title: 'Website → APK', desc: 'Paste any URL and get a signed APK in minutes.' },
  { icon: Code2, title: 'In-Browser Code Editor', desc: 'Monaco-powered IDE with instant live preview.' },
  { icon: Zap, title: 'Fast Builds', desc: 'Optimized build pipeline — under 2 minutes.' },
  { icon: ShieldCheck, title: 'Secure by Default', desc: 'Sandboxed WebView, no hidden permissions.' },
  { icon: Image, title: 'Icon & Splash Customization', desc: 'Upload your icon and pick a splash color.' },
  { icon: Download, title: 'One-Click Export', desc: 'Download ready-to-install APK in one click.' },
]

export function Features() {
  return (
    <section id="features" className="py-20 md:py-28">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-2xl text-center">
          <h2 className="text-3xl md:text-4xl font-bold tracking-tight">Everything you need to ship</h2>
          <p className="mt-4 text-muted-foreground">A complete toolkit to convert the web into native apps.</p>
        </div>
        <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {features.map((f, i) => (
            <motion.div key={f.title} initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.05 }} className="rounded-xl border border-border bg-card p-6 transition hover:border-primary/30 hover:shadow-lg">
              <div className="grid h-11 w-11 place-items-center rounded-full bg-primary/10 text-primary"><f.icon className="h-5 w-5" /></div>
              <h3 className="mt-4 font-semibold">{f.title}</h3>
              <p className="mt-1 text-sm text-muted-foreground">{f.desc}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}