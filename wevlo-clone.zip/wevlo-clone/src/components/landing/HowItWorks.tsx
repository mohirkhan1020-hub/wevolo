const steps = [
  { n: '1', title: 'Enter URL or paste code', desc: 'Start from any website or your own HTML/CSS/JS.' },
  { n: '2', title: 'Customize app', desc: 'Pick icon, splash color, and permissions.' },
  { n: '3', title: 'Download APK', desc: 'Get a signed, installable Android app.' },
]

export function HowItWorks() {
  return (
    <section className="border-y border-border bg-muted/30 py-20 md:py-28">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-2xl text-center">
          <h2 className="text-3xl md:text-4xl font-bold tracking-tight">How it works</h2>
          <p className="mt-4 text-muted-foreground">Three simple steps from idea to APK.</p>
        </div>
        <div className="relative mt-14">
          <div className="absolute left-1/2 top-8 hidden h-px w-2/3 -translate-x-1/2 bg-border lg:block" />
          <div className="grid gap-8 lg:grid-cols-3">
            {steps.map((s) => (
              <div key={s.n} className="relative text-center">
                <div className="relative z-10 mx-auto grid h-16 w-16 place-items-center rounded-full border border-border bg-card text-xl font-bold text-primary shadow">{s.n}</div>
                <h3 className="mt-4 font-semibold">{s.title}</h3>
                <p className="mt-1 text-sm text-muted-foreground">{s.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}