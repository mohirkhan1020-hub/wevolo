import { motion } from 'framer-motion'
import { Link } from 'react-router-dom'
import { ArrowRight, Zap, ShieldCheck, Globe, Code2, Smartphone } from 'lucide-react'
import { Button } from '@/components/ui/button'

const pills = [
  { icon: Zap, label: 'Fast & Easy Build' },
  { icon: ShieldCheck, label: 'Secure & Reliable' },
  { icon: Globe, label: 'Website to App' },
  { icon: Code2, label: 'Code Editor & more' },
]
const container = { hidden: {}, show: { transition: { staggerChildren: 0.1 } } }
const item = { hidden: { opacity: 0, y: 20 }, show: { opacity: 1, y: 0, transition: { duration: 0.5 } } }

export function Hero() {
  return (
    <section className="relative overflow-hidden dot-grid">
      <div className="glow" />
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-20 md:py-28">
        <motion.div variants={container} initial="hidden" animate="show" className="mx-auto max-w-3xl text-center">
          <motion.h1 variants={item} className="text-5xl md:text-6xl lg:text-7xl font-bold tracking-tight">
            Welcome to <span className="text-primary">Wevlo</span>
          </motion.h1>
          <motion.p variants={item} className="mt-6 text-lg md:text-xl text-muted-foreground">
            Turn your website or code into a powerful Android app in minutes.
          </motion.p>
          <motion.div variants={item} className="mt-8 flex flex-col sm:flex-row items-center justify-center gap-3">
            <Button asChild size="lg" className="w-full sm:w-auto"><Link to="/auth">Get Started Free <ArrowRight className="ml-2 h-4 w-4" /></Link></Button>
            <Button asChild variant="outline" size="lg" className="w-full sm:w-auto"><a href="#features">View Demo</a></Button>
          </motion.div>
          <motion.div variants={item} className="mt-10 flex flex-wrap items-center justify-center gap-2">
            {pills.map((p) => (
              <div key={p.label} className="flex items-center gap-2 rounded-full border border-border bg-card/60 px-3 py-1.5 text-xs font-medium backdrop-blur">
                <p.icon className="h-3.5 w-3.5 text-primary" />{p.label}
              </div>
            ))}
          </motion.div>
        </motion.div>
        <motion.div initial={{ opacity: 0, y: 40 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.5, duration: 0.7 }} className="relative mx-auto mt-16 max-w-4xl">
          <div className="rounded-2xl border border-border bg-card p-2 shadow-2xl shadow-primary/10">
            <div className="flex items-center gap-1.5 px-3 py-2">
              <div className="h-3 w-3 rounded-full bg-red-400" /><div className="h-3 w-3 rounded-full bg-yellow-400" /><div className="h-3 w-3 rounded-full bg-green-400" />
            </div>
            <div className="grid gap-4 rounded-xl bg-muted/50 p-6 md:grid-cols-5">
              <div className="md:col-span-3 space-y-3">
                <div className="h-3 w-3/4 rounded-full bg-border" /><div className="h-3 w-full rounded-full bg-border" /><div className="h-3 w-5/6 rounded-full bg-border" />
                <div className="mt-6 h-40 rounded-lg border border-border bg-background" />
              </div>
              <div className="md:col-span-2 flex items-center justify-center">
                <div className="h-56 w-28 rounded-3xl border-4 border-foreground/80 bg-background p-2">
                  <div className="flex h-full flex-col items-center justify-center gap-2">
                    <Smartphone className="h-6 w-6 text-primary" />
                    <div className="h-1.5 w-12 rounded-full bg-border" /><div className="h-1.5 w-8 rounded-full bg-border" />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  )
}