import { Link } from 'react-router-dom'
import { Globe, Code2, Download, Pencil, Trash2 } from 'lucide-react'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { cn } from '@/lib/utils'
import type { Project } from '@/types'

const statusVariant = { draft: 'secondary', building: 'warning', ready: 'success', failed: 'destructive' } as const

export function ProjectCard({ project, onDelete }: { project: Project; onDelete: (id: string) => void }) {
  const Icon = project.type === 'website' ? Globe : Code2
  return (
    <div className="group rounded-xl border border-border bg-card p-4 transition hover:border-primary/30 hover:shadow-lg">
      <div className="flex items-start gap-3">
        <div className="grid h-11 w-11 shrink-0 place-items-center rounded-lg text-white" style={{ backgroundColor: project.splash_color ?? '#6366F1' }}><Icon className="h-5 w-5" /></div>
        <div className="min-w-0 flex-1">
          <div className="flex items-center justify-between gap-2">
            <Link to={`/project/${project.id}`} className="truncate font-semibold hover:underline">{project.name}</Link>
            <Badge variant={statusVariant[project.status] as never}>
              {project.status === 'building' && <span className="mr-1 inline-block h-1.5 w-1.5 animate-pulse rounded-full bg-current" />}
              {project.status}
            </Badge>
          </div>
          <p className="mt-0.5 truncate text-xs text-muted-foreground">{project.type === 'website' ? project.source_url : project.package_id}</p>
          <p className="mt-1 text-xs text-muted-foreground">{new Date(project.created_at).toLocaleDateString()}</p>
        </div>
      </div>
      <div className="mt-4 flex items-center gap-2">
        <Button asChild variant="outline" size="sm" className="flex-1"><Link to={`/project/${project.id}`}><Pencil className="mr-1 h-3.5 w-3.5" /> Edit</Link></Button>
        <Button variant="outline" size="sm" disabled={!project.apk_url} className={cn('flex-1', !project.apk_url && 'opacity-50')} onClick={() => project.apk_url && window.open(project.apk_url, '_blank')}>
          <Download className="mr-1 h-3.5 w-3.5" /> Download
        </Button>
        <Button variant="ghost" size="icon" aria-label="Delete project" onClick={() => onDelete(project.id)}><Trash2 className="h-4 w-4 text-destructive" /></Button>
      </div>
    </div>
  )
}