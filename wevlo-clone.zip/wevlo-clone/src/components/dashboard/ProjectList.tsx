import { Link } from 'react-router-dom'
import { Plus, Sparkles } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { ProjectCard } from './ProjectCard'
import type { Project } from '@/types'

export function ProjectList({ projects, onDelete }: { projects: Project[]; onDelete: (id: string) => void }) {
  if (projects.length === 0) {
    return (
      <div className="rounded-xl border border-dashed border-border bg-card/40 p-12 text-center">
        <div className="mx-auto grid h-16 w-16 place-items-center rounded-full bg-primary/10 text-primary"><Sparkles className="h-7 w-7" /></div>
        <h3 className="mt-4 font-semibold">No apps yet. Create your first app →</h3>
        <p className="mt-1 text-sm text-muted-foreground">Your projects will appear here once you create one.</p>
        <Button asChild className="mt-5"><Link to="/new"><Plus className="mr-2 h-4 w-4" />Create New App</Link></Button>
      </div>
    )
  }
  return (
    <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
      {projects.map((p) => <ProjectCard key={p.id} project={p} onDelete={onDelete} />)}
    </div>
  )
}