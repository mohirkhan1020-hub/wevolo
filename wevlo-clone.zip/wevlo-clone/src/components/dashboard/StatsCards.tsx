import { useMemo } from 'react'
import { AppWindow, Loader2, CheckCircle2, HardDrive } from 'lucide-react'
import { Card, CardContent } from '@/components/ui/card'
import type { Project } from '@/types'

export function StatsCards({ projects }: { projects: Project[] }) {
  const stats = useMemo(() => {
    const total = projects.length
    const building = projects.filter((p) => p.status === 'building').length
    const ready = projects.filter((p) => p.status === 'ready').length
    const storageMb = projects.reduce((acc, p) => acc + (p.apk_url ? 2.4 : 0), 0)
    return { total, building, ready, storage: storageMb.toFixed(1) }
  }, [projects])
  const cards = [
    { label: 'Total Apps', value: stats.total, icon: AppWindow, tone: 'text-primary' },
    { label: 'Building', value: stats.building, icon: Loader2, tone: 'text-amber-500' },
    { label: 'Ready', value: stats.ready, icon: CheckCircle2, tone: 'text-accent' },
    { label: 'Storage used', value: `${stats.storage} MB`, icon: HardDrive, tone: 'text-indigo-500' },
  ]
  return (
    <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
      {cards.map((c) => (
        <Card key={c.label}>
          <CardContent className="flex items-center gap-4 p-5">
            <div className={`grid h-11 w-11 place-items-center rounded-lg bg-muted ${c.tone}`}><c.icon className="h-5 w-5" /></div>
            <div>
              <div className="text-xs text-muted-foreground">{c.label}</div>
              <div className="text-xl font-bold">{c.value}</div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}