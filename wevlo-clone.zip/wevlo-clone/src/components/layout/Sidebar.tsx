import { Link, useLocation, useNavigate } from 'react-router-dom'
import { LayoutDashboard, Plus, Settings, LogOut, Box } from 'lucide-react'
import { cn } from '@/lib/utils'
import { supabase } from '@/lib/supabase'
import { useAuthStore } from '@/store/authStore'

const items = [
  { label: 'Dashboard', href: '/dashboard', icon: LayoutDashboard },
  { label: 'New App', href: '/new', icon: Plus },
  { label: 'Settings', href: '/settings', icon: Settings },
]

export function Sidebar({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { pathname } = useLocation()
  const navigate = useNavigate()
  const reset = useAuthStore((s) => s.reset)

  const signOut = async () => {
    await supabase.auth.signOut()
    reset()
    navigate('/')
  }

  return (
    <>
      {open && <div className="fixed inset-0 z-30 bg-black/40 lg:hidden" onClick={onClose} />}
      <aside className={cn('fixed inset-y-0 left-0 z-40 w-64 border-r border-border bg-card transition-transform lg:static lg:translate-x-0', open ? 'translate-x-0' : '-translate-x-full')}>
        <div className="flex h-16 items-center border-b border-border px-4">
          <Link to="/" className="flex items-center gap-2 font-bold">
            <div className="grid h-8 w-8 place-items-center rounded-lg bg-primary text-primary-foreground"><Box className="h-5 w-5" /></div>
            Wevlo
          </Link>
        </div>
        <nav className="space-y-1 p-3">
          {items.map((it) => {
            const active = pathname === it.href || pathname.startsWith(it.href + '/')
            return (
              <Link key={it.href} to={it.href} onClick={onClose} className={cn('flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition', active ? 'bg-primary/10 text-primary' : 'text-muted-foreground hover:bg-muted hover:text-foreground')}>
                <it.icon className="h-4 w-4" />{it.label}
              </Link>
            )
          })}
        </nav>
        <div className="absolute bottom-3 left-3 right-3">
          <button onClick={signOut} className="flex w-full items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium text-muted-foreground transition hover:bg-muted hover:text-foreground">
            <LogOut className="h-4 w-4" />Sign out
          </button>
        </div>
      </aside>
    </>
  )
}