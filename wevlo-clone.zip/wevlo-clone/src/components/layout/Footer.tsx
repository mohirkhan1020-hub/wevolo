import { Link } from 'react-router-dom'
import { Github, Twitter, Linkedin, Box } from 'lucide-react'

const cols = [
  { title: 'Product', links: ['Features', 'Pricing', 'Changelog', 'Roadmap'] },
  { title: 'Company', links: ['About', 'Blog', 'Careers', 'Contact'] },
  { title: 'Resources', links: ['Docs', 'API', 'Guides', 'Status'] },
  { title: 'Legal', links: ['Terms', 'Privacy', 'Security', 'Cookies'] },
]

export function Footer() {
  return (
    <footer className="border-t border-border bg-muted/30">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid gap-8 md:grid-cols-6">
          <div className="md:col-span-2">
            <Link to="/" className="flex items-center gap-2 font-bold text-lg">
              <div className="grid h-8 w-8 place-items-center rounded-lg bg-primary text-primary-foreground"><Box className="h-5 w-5" /></div>
              Wevlo
            </Link>
            <p className="mt-3 max-w-xs text-sm text-muted-foreground">Turn your website or code into a powerful Android app in minutes.</p>
            <div className="mt-4 flex items-center gap-3">
              <a href="#" aria-label="GitHub" className="text-muted-foreground hover:text-foreground"><Github className="h-4 w-4" /></a>
              <a href="#" aria-label="Twitter" className="text-muted-foreground hover:text-foreground"><Twitter className="h-4 w-4" /></a>
              <a href="#" aria-label="LinkedIn" className="text-muted-foreground hover:text-foreground"><Linkedin className="h-4 w-4" /></a>
            </div>
          </div>
          {cols.map((c) => (
            <div key={c.title}>
              <h4 className="text-sm font-semibold">{c.title}</h4>
              <ul className="mt-3 space-y-2">
                {c.links.map((l) => <li key={l}><a href="#" className="text-sm text-muted-foreground hover:text-foreground">{l}</a></li>)}
              </ul>
            </div>
          ))}
        </div>
        <div className="mt-10 flex flex-col gap-2 border-t border-border pt-6 text-xs text-muted-foreground sm:flex-row sm:items-center sm:justify-between">
          <p>© 2025 Wevlo. All rights reserved.</p>
          <p>Built with ❤️ for makers</p>
        </div>
      </div>
    </footer>
  )
}