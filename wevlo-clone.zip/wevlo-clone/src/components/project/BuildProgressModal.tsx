import { useEffect, useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Check, Loader2 } from 'lucide-react'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Progress } from '@/components/ui/progress'
import { Button } from '@/components/ui/button'

const STEPS = ['Validating', 'Bundling', 'Signing', 'Done'] as const

export function BuildProgressModal({ open, onComplete, onClose }: { open: boolean; onComplete: () => void; onClose: () => void }) {
  const [step, setStep] = useState(0)
  useEffect(() => {
    if (!open) { setStep(0); return }
    const timers = [
      setTimeout(() => setStep(1), 900),
      setTimeout(() => setStep(2), 2000),
      setTimeout(() => setStep(3), 3200),
    ]
    return () => timers.forEach(clearTimeout)
  }, [open])
  useEffect(() => {
    if (step === 3 && open) {
      const t = setTimeout(() => onComplete(), 600)
      return () => clearTimeout(t)
    }
  }, [step, open, onComplete])
  const pct = (step / (STEPS.length - 1)) * 100
  return (
    <Dialog open={open} onOpenChange={(v) => !v && onClose()}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Building your APK</DialogTitle>
          <DialogDescription>This usually takes under 2 minutes.</DialogDescription>
        </DialogHeader>
        <div className="space-y-4">
          <Progress value={pct} />
          <AnimatePresence mode="wait">
            <motion.ul key={step} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="space-y-2">
              {STEPS.map((s, i) => {
                const done = i < step
                const active = i === step
                return (
                  <li key={s} className="flex items-center gap-3 text-sm">
                    <span className={`grid h-6 w-6 place-items-center rounded-full ${done ? 'bg-accent text-accent-foreground' : active ? 'bg-primary text-primary-foreground' : 'bg-muted text-muted-foreground'}`}>
                      {done ? <Check className="h-3.5 w-3.5" /> : active ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : i + 1}
                    </span>
                    <span className={done || active ? 'text-foreground' : 'text-muted-foreground'}>{s}</span>
                  </li>
                )
              })}
            </motion.ul>
          </AnimatePresence>
          {step === 3 && <Button className="w-full" onClick={onClose}>Close</Button>}
        </div>
      </DialogContent>
    </Dialog>
  )
}