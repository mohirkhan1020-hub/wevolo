import { FileCode2, FileText, FileJson } from 'lucide-react'
import { cn } from '@/lib/utils'

export type FileKey = 'html' | 'css' | 'js'
const files: { key: FileKey; label: string; icon: typeof FileCode2 }[] = [
  { key: 'html', label: 'index.html', icon: FileText },
  { key: 'css', label: 'style.css', icon: FileCode2 },
  { key: 'js', label: 'script.js', icon: FileJson },
]

export function FileTree({ active, onSelect }: { active: FileKey; onSelect: (k: FileKey) => void }) {
  return (
    <div className="border-r border-border bg-muted/30 p-3">
      <div className="mb-2 px-2 text-xs font-semibold uppercase text-muted-foreground">Files</div>
      <ul className="space-y-1">
        {files.map((f) => (
          <li key={f.key}>
            <button onClick={() => onSelect(f.key)} className={cn('flex w-full items-center gap-2 rounded-md px-2 py-1.5 text-left text-sm transition', active === f.key ? 'bg-primary/10 text-primary' : 'hover:bg-muted')}>
              <f.icon className="h-3.5 w-3.5" />{f.label}
            </button>
          </li>
        ))}
      </ul>
    </div>
  )
}