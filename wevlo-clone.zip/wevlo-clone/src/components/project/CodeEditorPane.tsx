import { useState } from 'react'
import Editor from '@monaco-editor/react'
import { FileTree, type FileKey } from './FileTree'
import { LivePreview } from './LivePreview'
import { useProjectStore } from '@/store/projectStore'
import { useThemeStore } from '@/store/themeStore'
import { Button } from '@/components/ui/button'
import { Play, Save, Upload } from 'lucide-react'
import { toast } from 'sonner'

const languageFor: Record<FileKey, string> = { html: 'html', css: 'css', js: 'javascript' }

export function CodeEditorPane({ projectId, onExport }: { projectId: string; onExport: () => void }) {
  const { getDraft, saveDraft } = useProjectStore()
  const theme = useThemeStore((s) => s.theme)
  const [active, setActive] = useState<FileKey>('html')
  const [draft, setDraft] = useState(() => getDraft(projectId))
  const [runKey, setRunKey] = useState(0)

  const onSave = () => { saveDraft(projectId, draft); toast.success('Draft saved to this device') }

  return (
    <div className="rounded-xl border border-border overflow-hidden">
      <div className="flex items-center justify-between gap-2 border-b border-border bg-muted/50 px-3 py-2">
        <div className="flex items-center gap-2">
          <Button size="sm" variant="outline" onClick={() => setRunKey((k) => k + 1)}><Play className="mr-1 h-3.5 w-3.5" /> Run</Button>
          <Button size="sm" variant="outline" onClick={onSave}><Save className="mr-1 h-3.5 w-3.5" /> Save Draft</Button>
        </div>
        <Button size="sm" onClick={onExport}><Upload className="mr-1 h-3.5 w-3.5" /> Export as App</Button>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-[160px_1fr_1fr] h-[520px]">
        <FileTree active={active} onSelect={setActive} />
        <div className="border-r border-border overflow-hidden">
          <Editor height="100%" language={languageFor[active]} theme={theme === 'dark' ? 'vs-dark' : 'light'} value={draft[active]} onChange={(value) => setDraft({ ...draft, [active]: value ?? '' })} options={{ minimap: { enabled: false }, fontSize: 13, wordWrap: 'on', scrollBeyondLastLine: false, automaticLayout: true }} />
        </div>
        <LivePreview draft={draft} runKey={runKey} />
      </div>
    </div>
  )
}