import { useMemo } from 'react'
import type { DraftState } from '@/store/projectStore'

export function LivePreview({ draft, runKey }: { draft: DraftState; runKey: number }) {
  const srcdoc = useMemo(() => {
    let html = draft.html
    html = html.replace('</head>', `<style>${draft.css}</style></head>`)
    html = html.replace('</body>', `<script>${draft.js.replace(/<\/script>/g, '<\\/script>')}</script></body>`)
    return html
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [runKey])
  return (
    <div className="flex flex-col bg-muted/30">
      <div className="border-b border-border px-3 py-2 text-xs font-semibold uppercase text-muted-foreground">Live Preview</div>
      <iframe title="Live Preview" srcDoc={srcdoc} sandbox="allow-scripts allow-same-origin" className="h-full min-h-[400px] w-full bg-white" />
    </div>
  )
}