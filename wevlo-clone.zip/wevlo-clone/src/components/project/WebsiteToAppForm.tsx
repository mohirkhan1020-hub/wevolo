import { useState } from 'react'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { Upload } from 'lucide-react'
import { websiteFormSchema, type WebsiteFormValues } from '@/lib/validators'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Checkbox } from '@/components/ui/checkbox'
import { generatePackageId, cn } from '@/lib/utils'

const PERMISSIONS = ['Internet', 'Camera', 'Location'] as const

export function WebsiteToAppForm({ onSubmit, pending }: { onSubmit: (v: WebsiteFormValues, iconFile: File | null) => void; pending?: boolean }) {
  const [iconFile, setIconFile] = useState<File | null>(null)
  const [iconUrl, setIconUrl] = useState<string | null>(null)
  const { register, handleSubmit, setValue, watch, formState: { errors, isValid } } = useForm<WebsiteFormValues>({
    resolver: zodResolver(websiteFormSchema), mode: 'onChange',
    defaultValues: { url: '', name: '', packageId: '', splashColor: '#6366F1', permissions: ['Internet'] },
  })
  const name = watch('name')
  const permissions = watch('permissions')
  const splashColor = watch('splashColor')

  const handleNameChange = (v: string) => {
    setValue('name', v, { shouldValidate: true })
    if (!watch('packageId')) setValue('packageId', generatePackageId(v), { shouldValidate: true })
  }
  const onFile = (f: File | null) => {
    if (!f || f.size > 1024 * 1024) return
    setIconFile(f); setIconUrl(URL.createObjectURL(f))
  }
  const togglePermission = (p: string) => {
    const next = permissions.includes(p) ? permissions.filter((x) => x !== p) : [...permissions, p]
    setValue('permissions', next, { shouldValidate: true })
  }

  return (
    <form onSubmit={handleSubmit((v) => onSubmit(v, iconFile))} className="space-y-6">
      <div className="grid gap-5 md:grid-cols-2">
        <div className="md:col-span-2 space-y-1.5">
          <Label htmlFor="url">Website URL</Label>
          <Input id="url" placeholder="https://example.com" {...register('url')} aria-invalid={!!errors.url} />
          {errors.url && <p role="alert" className="text-xs text-destructive">{errors.url.message}</p>}
        </div>
        <div className="space-y-1.5">
          <Label htmlFor="name">App Name</Label>
          <Input id="name" placeholder="My Awesome App" value={name} onChange={(e) => handleNameChange(e.target.value)} aria-invalid={!!errors.name} />
          {errors.name && <p role="alert" className="text-xs text-destructive">{errors.name.message}</p>}
        </div>
        <div className="space-y-1.5">
          <Label htmlFor="packageId">Package ID</Label>
          <Input id="packageId" placeholder="com.example.app" {...register('packageId')} aria-invalid={!!errors.packageId} />
          {errors.packageId && <p role="alert" className="text-xs text-destructive">{errors.packageId.message}</p>}
        </div>
        <div className="space-y-1.5">
          <Label>App Icon</Label>
          <div className="flex items-center gap-4">
            <label className="relative grid h-16 w-16 cursor-pointer place-items-center overflow-hidden rounded-full border-2 border-dashed border-border bg-muted text-muted-foreground hover:border-primary">
              {iconUrl ? <img src={iconUrl} alt="App icon preview" className="h-full w-full object-cover" /> : <Upload className="h-5 w-5" />}
              <input type="file" accept="image/png,image/jpeg" className="absolute inset-0 cursor-pointer opacity-0" onChange={(e) => onFile(e.target.files?.[0] ?? null)} />
            </label>
            <div className="text-xs text-muted-foreground">PNG or JPG, up to 1MB</div>
          </div>
        </div>
        <div className="space-y-1.5">
          <Label htmlFor="splashColor">Splash Color</Label>
          <div className="flex items-center gap-2">
            <input type="color" value={splashColor} onChange={(e) => setValue('splashColor', e.target.value, { shouldValidate: true })} className="h-9 w-14 cursor-pointer rounded-lg border border-border bg-background p-1" />
            <Input id="splashColor" {...register('splashColor')} className="font-mono" />
          </div>
          {errors.splashColor && <p role="alert" className="text-xs text-destructive">{errors.splashColor.message}</p>}
        </div>
        <div className="md:col-span-2 space-y-2">
          <Label>Permissions</Label>
          <div className="flex flex-wrap gap-3">
            {PERMISSIONS.map((p) => (
              <label key={p} className="flex cursor-pointer items-center gap-2 rounded-lg border border-border px-3 py-2">
                <Checkbox checked={permissions.includes(p)} onCheckedChange={() => togglePermission(p)} />
                <span className="text-sm">{p}</span>
              </label>
            ))}
          </div>
        </div>
      </div>
      <div className={cn('flex items-center justify-between border-t border-border pt-4')}>
        <p className="text-xs text-muted-foreground">Your code & drafts never leave this device.</p>
        <Button type="submit" disabled={!isValid || pending}>
          {pending && <span className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-current border-t-transparent" />}Build APK →
        </Button>
      </div>
    </form>
  )
}