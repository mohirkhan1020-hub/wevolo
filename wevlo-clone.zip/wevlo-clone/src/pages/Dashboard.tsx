import { useState } from 'react'
import { Helmet } from 'react-helmet-async'
import { Link } from 'react-router-dom'
import { Menu, Plus } from 'lucide-react'
import { toast } from 'sonner'
import { Sidebar } from '@/components/layout/Sidebar'
import { Button } from '@/components/ui/button'
import { StatsCards } from '@/components/dashboard/StatsCards'
import { ProjectList } from '@/components/dashboard/ProjectList'
import { useProjects, useDeleteProject } from '@/hooks/useProjects'
import { useAuth } from '@/hooks/useAuth'

export default function Dashboard() {
  const { user } = useAuth()
  const { data: projects = [], isLoading, error } = useProjects()
  const del = useDeleteProject()
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const firstName = user?.email?.split('@')[0] ?? 'friend'

  const handleDelete = (id: string) => {
    if (!confirm('Delete this project? This cannot be undone.')) return
    del.mutate(id, {
      onSuccess: () => toast.success('Project deleted'),
      onError: (e) => toast.error(e instanceof Error ? e.message : 'Delete failed'),
    })
  }

  return (
    <>
      <Helmet><title>Dashboard — Wevlo</title></Helmet>
      <div className="flex min-h-screen">
        <Sidebar open={sidebarOpen} onClose={() => setSidebarOpen(false)} />
        <div className="flex flex-1 flex-col">
          <header className="flex h-16 items-center justify-between border-b border-border px-4 lg:px-8">
            <div className="flex items-center gap-2">
              <button className="lg:hidden" onClick={() => setSidebarOpen(true)} aria-label="Open menu"><Menu className="h-5 w-5" /></button>
              <h1 className="font-semibold">Dashboard</h1>
            </div>
            <Button asChild><Link to="/new"><Plus className="mr-2 h-4 w-4" />Create New App</Link></Button>
          </header>
          <main className="flex-1 p-4 lg:p-8 space-y-6">
            <div>
              <h2 className="text-2xl font-bold">Welcome back, {firstName} 👋</h2>
              <p className="text-sm text-muted-foreground">Here's what's happening with your apps.</p>
            </div>
            <StatsCards projects={projects} />
            {isLoading ? (
              <div className="grid place-items-center py-20"><div className="h-8 w-8 animate-spin rounded-full border-2 border-primary border-t-transparent" /></div>
            ) : error ? (
              <div className="rounded-xl border border-destructive/40 bg-destructive/5 p-6 text-sm text-destructive">Failed to load projects: {(error as Error).message}</div>
            ) : (
              <ProjectList projects={projects} onDelete={handleDelete} />
            )}
          </main>
        </div>
      </div>
    </>
  )
}