import { Helmet } from 'react-helmet-async'
import { Navbar } from '@/components/layout/Navbar'
import { Footer } from '@/components/layout/Footer'
import { Hero } from '@/components/landing/Hero'
import { Features } from '@/components/landing/Features'
import { HowItWorks } from '@/components/landing/HowItWorks'
import { Pricing } from '@/components/landing/Pricing'
import { CTA } from '@/components/landing/CTA'

export default function Landing() {
  return (
    <>
      <Helmet>
        <title>Wevlo — Turn your website into an Android app</title>
        <meta name="description" content="Turn your website or code into a powerful Android app in minutes." />
      </Helmet>
      <Navbar />
      <main>
        <Hero /><Features /><HowItWorks /><Pricing /><CTA />
      </main>
      <Footer />
    </>
  )
}