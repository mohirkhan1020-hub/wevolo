import { Helmet } from 'react-helmet-async'
import { motion } from 'framer-motion'
import { Quote } from 'lucide-react'
import { AuthForm } from '@/components/auth/AuthForm'
import { Navbar } from '@/components/layout/Navbar'

export default function Auth() {
  return (
    <>
      <Helmet><title>Sign in — Wevlo</title></Helmet>
      <Navbar />
      <main className="grid min-h-[calc(100vh-4rem)] lg:grid-cols-2">
        <section className="relative hidden overflow-hidden bg-gradient-to-br from-primary/90 via-primary to-indigo-700 p-12 text-primary-foreground lg:flex lg:flex-col lg:justify-between">
          <div className="absolute inset-0 opacity-10 dot-grid" />
          <div className="relative">
            <h1 className="text-3xl font-bold">Build Android apps from the web.</h1>
            <p className="mt-3 max-w-sm text-primary-foreground/80">Convert any website or HTML/CSS/JS bundle into a signed APK — in minutes.</p>
          </div>
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }} className="relative rounded-2xl bg-white/10 p-6 backdrop-blur">
            <Quote className="h-6 w-6 opacity-60" />
            <p className="mt-2 text-sm leading-relaxed">"Wevlo shipped our first internal Android app in under 5 minutes. The code editor is a game changer."</p>
            <p className="mt-3 text-xs font-semibold opacity-80">— Priya N., Indie Maker</p>
          </motion.div>
        </section>
        <section className="flex items-center justify-center p-6"><AuthForm /></section>
      </main>
    </>
  )
}