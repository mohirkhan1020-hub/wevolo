import { useState } from 'react'
import { Helmet } from 'react-helmet-async'
import { Menu } from 'lucide-react'
import { toast } from 'sonner'
import { Sidebar } from '@/components/layout/Sidebar'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { useAuth } from '@/hooks/useAuth'
import { supabase } from '@/lib/supabase'

export default function Settings() {
  const { user } = useAuth()
  const [fullName, setFullName] = useState(user?.fullName ?? '')
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const save = async () => {
    const { error } = await supabase.auth.updateUser({ data: { full_name: fullName } })
    if (error) toast.error(error.message)
    else toast.success('Profile updated')
  }
  return (
    <>
      <Helmet><title>Settings — Wevlo</title></Helmet>
      <div className="flex min-h-screen">
        <Sidebar open={sidebarOpen} onClose={() => setSidebarOpen(false)} />
        <div className="flex-1">
          <header className="flex h-16 items-center gap-2 border-b border-border px-4 lg:px-8">
            <button className="lg:hidden" onClick={() => setSidebarOpen(true)} aria-label="Open menu"><Menu className="h-5 w-5" /></button>
            <h1 className="font-semibold">Settings</h1>
          </header>
          <main className="max-w-2xl space-y-6 p-4 lg:p-8">
            <div className="rounded-xl border border-border bg-card p-6 space-y-4">
              <h2 className="font-semibold">Profile</h2>
              <div className="space-y-1.5"><Label htmlFor="email">Email</Label><Input id="email" value={user?.email ?? ''} disabled /></div>
              <div className="space-y-1.5"><Label htmlFor="fullName">Full name</Label><Input id="fullName" value={fullName} onChange={(e) => setFullName(e.target.value)} /></div>
              <Button onClick={save}>Save changes</Button>
            </div>
          </main>
        </div>
      </div>
    </>
  )
}