import { lazy, Suspense, useState } from 'react'
import { Helmet } from 'react-helmet-async'
import { useNavigate } from 'react-router-dom'
import { toast } from 'sonner'
import { Menu } from 'lucide-react'
import { Sidebar } from '@/components/layout/Sidebar'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { WebsiteToAppForm } from '@/components/project/WebsiteToAppForm'
import { BuildProgressModal } from '@/components/project/BuildProgressModal'
import { useCreateProject, useUpdateProject } from '@/hooks/useProjects'
import { useAuth } from '@/hooks/useAuth'
import { supabase } from '@/lib/supabase'
import type { WebsiteFormValues } from '@/lib/validators'

const CodeEditorPane = lazy(() => import('@/components/project/CodeEditorPane').then((m) => ({ default: m.CodeEditorPane })))

export default function NewProject() {
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const [progressOpen, setProgressOpen] = useState(false)
  const navigate = useNavigate()
  const { user } = useAuth()
  const create = useCreateProject()
  const update = useUpdateProject()

  const finishBuild = async (id: string) => {
    await update.mutateAsync({ id, patch: { status: 'ready' } })
    toast.success('Build complete!')
    setProgressOpen(false)
    navigate(`/project/${id}`)
  }

  const handleWebsiteSubmit = async (values: WebsiteFormValues, iconFile: File | null) => {
    if (!user) return
    let iconUrl: string | null = null
    if (iconFile) {
      const path = `${user.id}/${Date.now()}-${iconFile.name}`
      const { error: upErr } = await supabase.storage.from('icons').upload(path, iconFile)
      if (!upErr) {
        const { data } = supabase.storage.from('icons').getPublicUrl(path)
        iconUrl = data.publicUrl
      }
    }
    create.mutate({
      user_id: user.id, name: values.name, type: 'website', source_url: values.url,
      package_id: values.packageId, splash_color: values.splashColor, permissions: values.permissions,
      icon_url: iconUrl, status: 'building',
    }, {
      onSuccess: (p) => { setProgressOpen(true); setTimeout(() => finishBuild(p.id), 3800) },
      onError: (e) => toast.error(e instanceof Error ? e.message : 'Failed to create project'),
    })
  }

  const handleCodeExport = async () => {
    if (!user) return
    create.mutate({
      user_id: user.id, name: `Code App ${new Date().toLocaleDateString()}`, type: 'code',
      package_id: `com.wevlo.code${Date.now().toString().slice(-6)}`, splash_color: '#6366F1',
      permissions: ['Internet'], status: 'building',
    }, {
      onSuccess: (p) => { setProgressOpen(true); setTimeout(() => finishBuild(p.id), 3800) },
      onError: (e) => toast.error(e instanceof Error ? e.message : 'Failed'),
    })
  }

  return (
    <>
      <Helmet><title>New App — Wevlo</title></Helmet>
      <div className="flex min-h-screen">
        <Sidebar open={sidebarOpen} onClose={() => setSidebarOpen(false)} />
        <div className="flex-1">
          <header className="flex h-16 items-center gap-2 border-b border-border px-4 lg:px-8">
            <button className="lg:hidden" onClick={() => setSidebarOpen(true)} aria-label="Open menu"><Menu className="h-5 w-5" /></button>
            <h1 className="font-semibold">Create New App</h1>
          </header>
          <main className="p-4 lg:p-8">
            <Tabs defaultValue="website">
              <TabsList className="mb-6">
                <TabsTrigger value="website">Website to App</TabsTrigger>
                <TabsTrigger value="code">Code Editor</TabsTrigger>
              </TabsList>
              <TabsContent value="website">
                <div className="rounded-xl border border-border bg-card p-6"><WebsiteToAppForm onSubmit={handleWebsiteSubmit} pending={create.isPending} /></div>
              </TabsContent>
              <TabsContent value="code">
                <Suspense fallback={<div className="grid place-items-center py-20"><div className="h-8 w-8 animate-spin rounded-full border-2 border-primary border-t-transparent" /></div>}>
                  <CodeEditorPane projectId="draft" onExport={handleCodeExport} />
                </Suspense>
              </TabsContent>
            </Tabs>
          </main>
        </div>
      </div>
      <BuildProgressModal open={progressOpen} onComplete={() => {}} onClose={() => setProgressOpen(false)} />
    </>
  )
}