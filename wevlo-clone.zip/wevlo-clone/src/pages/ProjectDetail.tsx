import { Helmet } from 'react-helmet-async'
import { useParams, Link } from 'react-router-dom'
import { useQuery } from '@tanstack/react-query'
import { ArrowLeft, Download, Globe, Code2 } from 'lucide-react'
import { supabase } from '@/lib/supabase'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import type { Project } from '@/types'

export default function ProjectDetail() {
  const { id } = useParams()
  const { data: project, isLoading } = useQuery({
    queryKey: ['project', id],
    queryFn: async (): Promise<Project> => {
      const { data, error } = await supabase.from('projects').select('*').eq('id', id).single()
      if (error) throw error
      return data
    },
    enabled: !!id,
  })
  if (isLoading || !project) {
    return <div className="grid min-h-screen place-items-center"><div className="h-8 w-8 animate-spin rounded-full border-2 border-primary border-t-transparent" /></div>
  }
  const Icon = project.type === 'website' ? Globe : Code2
  return (
    <>
      <Helmet><title>{project.name} — Wevlo</title></Helmet>
      <div className="mx-auto max-w-4xl p-6 lg:p-10">
        <Link to="/dashboard" className="mb-6 inline-flex items-center text-sm text-muted-foreground hover:text-foreground">
          <ArrowLeft className="mr-1 h-4 w-4" /> Back to dashboard
        </Link>
        <div className="rounded-xl border border-border bg-card p-6">
          <div className="flex items-start gap-4">
            <div className="grid h-16 w-16 place-items-center rounded-xl text-white" style={{ backgroundColor: project.splash_color ?? '#6366F1' }}><Icon className="h-7 w-7" /></div>
            <div className="flex-1">
              <div className="flex items-center justify-between gap-2">
                <h1 className="text-2xl font-bold">{project.name}</h1>
                <Badge>{project.status}</Badge>
              </div>
              <p className="mt-1 text-sm text-muted-foreground">{project.package_id}</p>
              {project.source_url && <a href={project.source_url} target="_blank" rel="noreferrer" className="mt-1 inline-block text-sm text-primary hover:underline">{project.source_url}</a>}
            </div>
          </div>
          <div className="mt-6 grid gap-4 sm:grid-cols-2">
            <div className="rounded-lg border border-border p-4"><div className="text-xs text-muted-foreground">Created</div><div className="font-medium">{new Date(project.created_at).toLocaleString()}</div></div>
            <div className="rounded-lg border border-border p-4"><div className="text-xs text-muted-foreground">Permissions</div><div className="font-medium">{project.permissions.join(', ')}</div></div>
          </div>
          <div className="mt-6 flex flex-wrap gap-3">
            <Button disabled={!project.apk_url} onClick={() => project.apk_url && window.open(project.apk_url, '_blank')}><Download className="mr-2 h-4 w-4" /> Download APK</Button>
            <Button asChild variant="outline"><Link to="/new">Duplicate & Edit</Link></Button>
          </div>
        </div>
      </div>
    </>
  )
}