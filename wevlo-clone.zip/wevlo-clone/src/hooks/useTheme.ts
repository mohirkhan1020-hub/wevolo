import { useEffect } from 'react'
import { useThemeStore } from '@/store/themeStore'

export function useTheme() {
  const { theme, toggle, hydrate } = useThemeStore()
  useEffect(() => { hydrate() }, [hydrate])
  return { theme, toggle }
}