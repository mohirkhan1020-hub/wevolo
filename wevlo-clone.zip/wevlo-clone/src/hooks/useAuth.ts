import { useEffect } from 'react'
import { supabase } from '@/lib/supabase'
import { useAuthStore } from '@/store/authStore'

export function useAuth() {
  const { user, loading, setUser, setLoading } = useAuthStore()
  useEffect(() => {
    let mounted = true
    supabase.auth.getSession().then(({ data }) => {
      if (!mounted) return
      const u = data.session?.user
      setUser(u ? { id: u.id, email: u.email ?? null, fullName: (u.user_metadata.full_name as string) ?? null, avatarUrl: (u.user_metadata.avatar_url as string) ?? null } : null)
      setLoading(false)
    })
    const { data: sub } = supabase.auth.onAuthStateChange((_e, session) => {
      const u = session?.user
      setUser(u ? { id: u.id, email: u.email ?? null, fullName: (u.user_metadata.full_name as string) ?? null, avatarUrl: (u.user_metadata.avatar_url as string) ?? null } : null)
      setLoading(false)
    })
    return () => { mounted = false; sub.subscription.unsubscribe() }
  }, [setUser, setLoading])
  return { user, loading }
}