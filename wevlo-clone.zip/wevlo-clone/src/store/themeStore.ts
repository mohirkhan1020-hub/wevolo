import { create } from 'zustand'

type Theme = 'light' | 'dark'
interface ThemeState {
  theme: Theme
  setTheme: (t: Theme) => void
  toggle: () => void
  hydrate: () => void
}
const KEY = 'wevlo-theme'

export const useThemeStore = create<ThemeState>((set, get) => ({
  theme: 'light',
  setTheme: (theme) => {
    localStorage.setItem(KEY, theme)
    document.documentElement.classList.toggle('dark', theme === 'dark')
    set({ theme })
  },
  toggle: () => {
    const next = get().theme === 'dark' ? 'light' : 'dark'
    get().setTheme(next)
  },
  hydrate: () => {
    const stored = localStorage.getItem(KEY) as Theme | null
    const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches
    const theme = stored ?? (prefersDark ? 'dark' : 'light')
    document.documentElement.classList.toggle('dark', theme === 'dark')
    set({ theme })
  },
}))