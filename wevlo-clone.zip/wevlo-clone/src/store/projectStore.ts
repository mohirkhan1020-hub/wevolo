import { create } from 'zustand'

export interface DraftState { html: string; css: string; js: string }

interface ProjectStore {
  drafts: Record<string, DraftState>
  getDraft: (id: string) => DraftState
  saveDraft: (id: string, d: DraftState) => void
}

const DEFAULT_DRAFT: DraftState = {
  html: '<!doctype html><html><head><meta charset="utf-8"><title>App</title></head><body><h1>Hello from Wevlo</h1><button id="btn">Click me</button><script src="script.js"></script></body></html>',
  css: 'body { font-family: system-ui; padding: 24px; background: #f9fafb; color: #111; } h1 { color: #6366F1; } button { padding: 10px 20px; background: #6366F1; color: #fff; border: none; border-radius: 8px; cursor: pointer; }',
  js: "document.getElementById('btn').addEventListener('click', () => { alert('Hello from Wevlo!') })",
}

const key = (id: string) => `wevlo:draft:${id}`

export const useProjectStore = create<ProjectStore>((set, get) => ({
  drafts: {},
  getDraft: (id) => {
    const fromState = get().drafts[id]
    if (fromState) return fromState
    try {
      const stored = localStorage.getItem(key(id))
      if (stored) return JSON.parse(stored) as DraftState
    } catch { /* ignore */ }
    return DEFAULT_DRAFT
  },
  saveDraft: (id, draft) => {
    localStorage.setItem(key(id), JSON.stringify(draft))
    set((s) => ({ drafts: { ...s.drafts, [id]: draft } }))
  },
}))