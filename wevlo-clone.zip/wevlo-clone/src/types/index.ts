export type ProjectType = 'website' | 'code'
export type ProjectStatus = 'draft' | 'building' | 'ready' | 'failed'

export interface Project {
  id: string
  user_id: string
  name: string
  type: ProjectType
  source_url: string | null
  package_id: string | null
  icon_url: string | null
  splash_color: string | null
  permissions: string[]
  status: ProjectStatus
  apk_url: string | null
  metadata: Record<string, unknown>
  created_at: string
  updated_at: string
}

export interface Profile {
  id: string
  full_name: string | null
  avatar_url: string | null
  created_at: string
}

export interface AuthUser {
  id: string
  email: string | null
  fullName: string | null
  avatarUrl: string | null
}