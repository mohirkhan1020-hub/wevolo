-- Replace <USER_UUID> with your auth.users.id
insert into projects (user_id, name, type, source_url, package_id, splash_color, status, permissions)
values
  ('<USER_UUID>', 'Portfolio Site', 'website', 'https://example.com', 'com.example.portfolio', '#6366F1', 'ready', '{Internet}'),
  ('<USER_UUID>', 'Todo Web App', 'code', null, 'com.example.todo', '#22C55E', 'draft', '{Internet}'),
  ('<USER_UUID>', 'Blog Reader', 'website', 'https://blog.example.com', 'com.example.blog', '#EF4444', 'building', '{Internet}');